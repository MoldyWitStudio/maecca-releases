#!/bin/sh
# Installs Maecca (native) for this user from this folder (the linux-x64 tar.gz), no root:
#   ~/.local/share/maecca-native/maecca-native        the app
#   ~/.local/share/maecca-native/maecca-call          the call helper (one process per call)
#   ~/.local/bin/maecca-native                        the launcher
#   ~/.local/share/applications/maecca-native.desktop the app-launcher entry
#   ~/.local/share/icons/hicolor/128x128/apps/maecca-native.png
# Run it again to reinstall; the in-app Update button replaces the binaries in place.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
share=$HOME/.local/share/maecca-native
apps=$HOME/.local/share/applications
icons=$HOME/.local/share/icons/hicolor/128x128/apps
mkdir -p "$share" "$HOME/.local/bin" "$apps" "$icons"
for b in maecca-native maecca-call; do
  install -m 755 "$here/$b" "$share/$b.new" && mv -f "$share/$b.new" "$share/$b"
done
# how this copy was installed: the in-app Update swaps it from the tar.gz (src/update/kind.rs)
printf 'tar\n' >"$share/install-kind"
install -m 644 "$here/maecca.png" "$icons/maecca-native.png"

cat >"$HOME/.local/bin/maecca-native" <<'LAUNCH'
#!/bin/sh
# Maecca native. Slint's software renderer (the RAM budget); SLINT_BACKEND=winit-femtovg for OpenGL.
export SLINT_BACKEND=${SLINT_BACKEND:-winit-software}
export MAECCA_DATA_DIR=${MAECCA_DATA_DIR:-$HOME/.local/share/maecca-native/data}
exec "$HOME/.local/share/maecca-native/maecca-native" "$@"
LAUNCH
chmod 755 "$HOME/.local/bin/maecca-native"

cat >"$apps/maecca-native.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Maecca
Comment=Maecca desktop
Exec=$HOME/.local/bin/maecca-native %u
Icon=maecca-native
Terminal=false
Categories=Network;Chat;
StartupWMClass=maecca-native
MimeType=x-scheme-handler/maecca;
DESK
command -v xdg-mime >/dev/null && xdg-mime default maecca-native.desktop x-scheme-handler/maecca || true
command -v update-desktop-database >/dev/null && update-desktop-database -q "$apps" || true
echo "installed: Maecca ($share/maecca-native); start it from your app launcher or with: maecca-native"
